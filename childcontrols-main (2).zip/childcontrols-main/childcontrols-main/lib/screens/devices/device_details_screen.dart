import 'package:flutter/material.dart';

class DeviceDetailsScreen extends StatelessWidget {
  final String deviceName;
  
  const DeviceDetailsScreen({
    super.key,
    required this.deviceName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(deviceName),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              // TODO: Show device options menu
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildDeviceInfoCard(),
          const SizedBox(height: 16),
          _buildQuickControls(),
          const SizedBox(height: 16),
          _buildInstalledApps(),
        ],
      ),
    );
  }

  Widget _buildDeviceInfoCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 40,
              child: Icon(Icons.phone_android, size: 40),
            ),
            const SizedBox(height: 16),
            Text(
              deviceName,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text('Last active: 2 minutes ago'),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildDeviceInfoItem(
                  icon: Icons.battery_full,
                  label: 'Battery',
                  value: '85%',
                ),
                _buildDeviceInfoItem(
                  icon: Icons.storage,
                  label: 'Storage',
                  value: '45% used',
                ),
                _buildDeviceInfoItem(
                  icon: Icons.wifi,
                  label: 'Network',
                  value: 'Wi-Fi',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceInfoItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Icon(icon),
        const SizedBox(height: 4),
        Text(label),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildQuickControls() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Quick Controls',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildQuickControlButton(
                  icon: Icons.lock,
                  label: 'Lock Device',
                  onPressed: () {
                    // TODO: Implement device lock
                  },
                ),
                _buildQuickControlButton(
                  icon: Icons.location_on,
                  label: 'Locate',
                  onPressed: () {
                    // TODO: Implement device location
                  },
                ),
                _buildQuickControlButton(
                  icon: Icons.notifications_off,
                  label: 'Mute',
                  onPressed: () {
                    // TODO: Implement device mute
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon),
          onPressed: onPressed,
          style: IconButton.styleFrom(
            backgroundColor: Colors.blue.withOpacity(0.1),
          ),
        ),
        const SizedBox(height: 4),
        Text(label),
      ],
    );
  }

  Widget _buildInstalledApps() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Installed Apps',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text('12 apps'),
              ],
            ),
            const SizedBox(height: 16),
            _buildAppTile(
              appName: 'YouTube Kids',
              isBlocked: false,
            ),
            _buildAppTile(
              appName: 'Minecraft',
              isBlocked: true,
            ),
            _buildAppTile(
              appName: 'Calculator',
              isBlocked: false,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppTile({
    required String appName,
    required bool isBlocked,
  }) {
    return ListTile(
      leading: const CircleAvatar(
        child: Icon(Icons.android),
      ),
      title: Text(appName),
      trailing: Switch(
        value: !isBlocked,
        onChanged: (value) {
          // TODO: Implement app blocking toggle
        },
      ),
    );
  }
} 