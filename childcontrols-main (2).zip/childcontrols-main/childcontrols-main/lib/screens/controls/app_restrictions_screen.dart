import 'package:flutter/material.dart';

class AppRestrictionsScreen extends StatefulWidget {
  const AppRestrictionsScreen({super.key});

  @override
  State<AppRestrictionsScreen> createState() => _AppRestrictionsScreenState();
}

class _AppRestrictionsScreenState extends State<AppRestrictionsScreen> {
  bool _appInstallationBlocked = true;
  bool _inAppPurchasesBlocked = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Restrictions'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildGeneralRestrictionsCard(),
          const SizedBox(height: 16),
          _buildAppScheduleCard(),
          const SizedBox(height: 16),
          _buildRestrictedAppsCard(),
          const SizedBox(height: 16),
          _buildAllowedAppsCard(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // TODO: Add new app restriction
        },
        icon: const Icon(Icons.add),
        label: const Text('Add App'),
      ),
    );
  }

  Widget _buildGeneralRestrictionsCard() {
    return Card(
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('Block App Installation'),
            subtitle: const Text('Prevent installing new apps'),
            value: _appInstallationBlocked,
            onChanged: (value) {
              setState(() {
                _appInstallationBlocked = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('Block In-App Purchases'),
            subtitle: const Text('Prevent purchases within apps'),
            value: _inAppPurchasesBlocked,
            onChanged: (value) {
              setState(() {
                _inAppPurchasesBlocked = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAppScheduleCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'App Schedule',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildScheduleTile(
              'Gaming Apps',
              'Blocked during study hours',
              Icons.games,
              Colors.red,
            ),
            _buildScheduleTile(
              'Social Media',
              'Limited to 2 hours/day',
              Icons.people,
              Colors.blue,
            ),
            _buildScheduleTile(
              'Educational Apps',
              'Always allowed',
              Icons.school,
              Colors.green,
            ),
            const SizedBox(height: 8),
            Center(
              child: TextButton.icon(
                onPressed: () {
                  // TODO: Add new schedule
                },
                icon: const Icon(Icons.add),
                label: const Text('Add New Schedule'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleTile(
    String name,
    String schedule,
    IconData icon,
    Color color,
  ) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(0.1),
        child: Icon(icon, color: color),
      ),
      title: Text(name),
      subtitle: Text(schedule),
      trailing: IconButton(
        icon: const Icon(Icons.edit),
        onPressed: () {
          // TODO: Edit schedule
        },
      ),
    );
  }

  Widget _buildRestrictedAppsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Restricted Apps',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Chip(
                  label: const Text('8 Apps'),
                  backgroundColor: Colors.red[100],
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildAppTile(
              'TikTok',
              'Blocked',
              Icons.block,
              Colors.red,
            ),
            _buildAppTile(
              'Instagram',
              'Time Limited',
              Icons.timer,
              Colors.orange,
            ),
            _buildAppTile(
              'PUBG Mobile',
              'Scheduled',
              Icons.schedule,
              Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAllowedAppsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Allowed Apps',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Chip(
                  label: const Text('5 Apps'),
                  backgroundColor: Colors.green[100],
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildAppTile(
              'Calculator',
              'Always allowed',
              Icons.check_circle,
              Colors.green,
            ),
            _buildAppTile(
              'Dictionary',
              'Always allowed',
              Icons.check_circle,
              Colors.green,
            ),
            _buildAppTile(
              'Educational Games',
              'Time Limited',
              Icons.timer,
              Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppTile(
    String name,
    String status,
    IconData icon,
    Color color,
  ) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(0.1),
        child: Icon(icon, color: color),
      ),
      title: Text(name),
      subtitle: Text(status),
      trailing: PopupMenuButton(
        itemBuilder: (context) => [
          const PopupMenuItem(
            value: 'edit',
            child: Text('Edit Restrictions'),
          ),
          const PopupMenuItem(
            value: 'remove',
            child: Text('Remove Restrictions'),
          ),
        ],
        onSelected: (value) {
          // TODO: Handle menu selection
        },
      ),
    );
  }
} 