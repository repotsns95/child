import 'package:flutter/material.dart';

class ScreenTimeScreen extends StatelessWidget {
  const ScreenTimeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Screen Time'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildDailyUsageCard(),
          const SizedBox(height: 16),
          _buildTimeRestrictionsCard(),
          const SizedBox(height: 16),
          _buildAppUsageList(),
        ],
      ),
    );
  }

  Widget _buildDailyUsageCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Today\'s Usage',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: 0.7,
              backgroundColor: Colors.grey[200],
              minHeight: 10,
              borderRadius: BorderRadius.circular(5),
            ),
            const SizedBox(height: 8),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('4h 12m / 6h'),
                Text('70%'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeRestrictionsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Time Restrictions',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Icon(Icons.add),
              ],
            ),
            const SizedBox(height: 16),
            _buildTimeRestrictionTile(
              title: 'Bedtime',
              startTime: '10:00 PM',
              endTime: '7:00 AM',
              isActive: true,
            ),
            _buildTimeRestrictionTile(
              title: 'Study Time',
              startTime: '4:00 PM',
              endTime: '6:00 PM',
              isActive: false,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeRestrictionTile({
    required String title,
    required String startTime,
    required String endTime,
    required bool isActive,
  }) {
    return ListTile(
      title: Text(title),
      subtitle: Text('$startTime - $endTime'),
      trailing: Switch(
        value: isActive,
        onChanged: (value) {
          // TODO: Implement time restriction toggle
        },
      ),
    );
  }

  Widget _buildAppUsageList() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'App Usage',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildAppUsageTile(
              appName: 'YouTube Kids',
              usageTime: '2h 15m',
              iconData: Icons.play_circle,
              color: Colors.red,
            ),
            _buildAppUsageTile(
              appName: 'Games',
              usageTime: '1h 30m',
              iconData: Icons.games,
              color: Colors.green,
            ),
            _buildAppUsageTile(
              appName: 'Educational Apps',
              usageTime: '45m',
              iconData: Icons.school,
              color: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppUsageTile({
    required String appName,
    required String usageTime,
    required IconData iconData,
    required Color color,
  }) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(0.1),
        child: Icon(iconData, color: color),
      ),
      title: Text(appName),
      trailing: Text(
        usageTime,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
} 