import 'package:flutter/material.dart';

class ContentFilteringScreen extends StatefulWidget {
  const ContentFilteringScreen({super.key});

  @override
  State<ContentFilteringScreen> createState() => _ContentFilteringScreenState();
}

class _ContentFilteringScreenState extends State<ContentFilteringScreen> {
  bool _webFilteringEnabled = true;
  bool _safeSearchEnabled = true;
  bool _youtubeRestrictedMode = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Content Filtering'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildWebFilteringCard(),
          const SizedBox(height: 16),
          _buildSafeSearchCard(),
          const SizedBox(height: 16),
          _buildBlockedContentCard(),
          const SizedBox(height: 16),
          _buildCustomFiltersCard(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // TODO: Implement add custom filter
        },
        icon: const Icon(Icons.add),
        label: const Text('Add Filter'),
      ),
    );
  }

  Widget _buildWebFilteringCard() {
    return Card(
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('Web Filtering'),
            subtitle: const Text('Block inappropriate websites'),
            value: _webFilteringEnabled,
            onChanged: (value) {
              setState(() {
                _webFilteringEnabled = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('Safe Search'),
            subtitle: const Text('Enforce safe search on Google and Bing'),
            value: _safeSearchEnabled,
            onChanged: (value) {
              setState(() {
                _safeSearchEnabled = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('YouTube Restricted Mode'),
            subtitle: const Text('Filter mature content on YouTube'),
            value: _youtubeRestrictedMode,
            onChanged: (value) {
              setState(() {
                _youtubeRestrictedMode = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSafeSearchCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Protection Level',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildProtectionLevelTile(
              title: 'High Protection',
              description: 'Block all potentially inappropriate content',
              isSelected: true,
            ),
            _buildProtectionLevelTile(
              title: 'Moderate Protection',
              description: 'Block mature content only',
              isSelected: false,
            ),
            _buildProtectionLevelTile(
              title: 'Low Protection',
              description: 'Block explicit content only',
              isSelected: false,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProtectionLevelTile({
    required String title,
    required String description,
    required bool isSelected,
  }) {
    return RadioListTile(
      title: Text(title),
      subtitle: Text(description),
      value: isSelected,
      groupValue: true,
      onChanged: (value) {
        // TODO: Implement protection level change
      },
    );
  }

  Widget _buildBlockedContentCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Blocked Content Categories',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildCategoryChip('Adult Content', true),
                _buildCategoryChip('Gambling', true),
                _buildCategoryChip('Violence', true),
                _buildCategoryChip('Weapons', true),
                _buildCategoryChip('Drugs', true),
                _buildCategoryChip('Social Media', false),
                _buildCategoryChip('Games', false),
                _buildCategoryChip('Dating', true),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryChip(String label, bool isSelected) {
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (value) {
        // TODO: Implement category selection
      },
    );
  }

  Widget _buildCustomFiltersCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Custom Filters',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildCustomFilterTile(
              'Block Facebook',
              'facebook.com',
              true,
            ),
            _buildCustomFilterTile(
              'Block Twitter',
              'twitter.com',
              true,
            ),
            _buildCustomFilterTile(
              'Block TikTok',
              'tiktok.com',
              false,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomFilterTile(
    String name,
    String url,
    bool isBlocked,
  ) {
    return ListTile(
      title: Text(name),
      subtitle: Text(url),
      trailing: Switch(
        value: isBlocked,
        onChanged: (value) {
          // TODO: Implement custom filter toggle
        },
      ),
    );
  }
} 