import 'package:flutter/material.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool _locationAlerts = true;
  bool _screenTimeAlerts = true;
  bool _appUsageAlerts = true;
  bool _deviceStatusAlerts = true;
  final bool _emergencyAlerts = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Settings'),
      ),
      body: ListView(
        children: [
          _buildImportantAlertsCard(),
          const SizedBox(height: 16),
          _buildGeneralNotificationsCard(),
          const SizedBox(height: 16),
          _buildScheduledReportsCard(),
          const SizedBox(height: 16),
          _buildQuietHoursCard(),
        ],
      ),
    );
  }

  Widget _buildImportantAlertsCard() {
    return Card(
      margin: const EdgeInsets.all(16),
      child: Column(
        children: [
          const ListTile(
            title: Text(
              'Important Alerts',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text('These notifications cannot be disabled'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.warning, color: Colors.red),
            title: const Text('Emergency Alerts'),
            subtitle: const Text('SOS and critical notifications'),
            trailing: Switch(
              value: _emergencyAlerts,
              onChanged: null,
            ),
          ),
          const ListTile(
            leading: Icon(Icons.security, color: Colors.orange),
            title: Text('Security Alerts'),
            subtitle: Text('Unauthorized access attempts'),
            trailing: Switch(
              value: true,
              onChanged: null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGeneralNotificationsCard() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('Location Alerts'),
            subtitle: const Text('Safe zone entry/exit notifications'),
            value: _locationAlerts,
            onChanged: (value) {
              setState(() {
                _locationAlerts = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('Screen Time Alerts'),
            subtitle: const Text('Daily limit and usage warnings'),
            value: _screenTimeAlerts,
            onChanged: (value) {
              setState(() {
                _screenTimeAlerts = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('App Usage Alerts'),
            subtitle: const Text('Restricted app access attempts'),
            value: _appUsageAlerts,
            onChanged: (value) {
              setState(() {
                _appUsageAlerts = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('Device Status'),
            subtitle: const Text('Battery, storage, and connectivity alerts'),
            value: _deviceStatusAlerts,
            onChanged: (value) {
              setState(() {
                _deviceStatusAlerts = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildScheduledReportsCard() {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Scheduled Reports',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildReportTile(
              'Daily Summary',
              'Screen time and app usage',
              const TimeOfDay(hour: 21, minute: 0),
            ),
            _buildReportTile(
              'Weekly Report',
              'Detailed activity analysis',
              null,
            ),
            _buildReportTile(
              'Location History',
              'Weekly location summary',
              null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportTile(String title, String description, TimeOfDay? time) {
    return ListTile(
      title: Text(title),
      subtitle: Text(description),
      trailing: time != null
          ? Text('${time.hour}:${time.minute.toString().padLeft(2, '0')}')
          : TextButton(
              onPressed: () {
                // TODO: Set up scheduled report
              },
              child: const Text('Set Up'),
            ),
    );
  }

  Widget _buildQuietHoursCard() {
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Quiet Hours',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO: Set start time
                    },
                    icon: const Icon(Icons.access_time),
                    label: const Text('10:00 PM'),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text('to'),
                ),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO: Set end time
                    },
                    icon: const Icon(Icons.access_time),
                    label: const Text('7:00 AM'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'Only emergency notifications will be shown during quiet hours',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
} 