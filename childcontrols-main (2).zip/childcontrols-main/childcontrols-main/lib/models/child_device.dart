class ChildDevice {
  final String id;
  final String childName;
  final String deviceName;
  bool isOnline;
  int dailyScreenTime; // in minutes
  int screenTimeLimit; // in minutes

  ChildDevice({
    required this.id,
    required this.childName,
    required this.deviceName,
    this.isOnline = true,
    this.dailyScreenTime = 0,
    this.screenTimeLimit = 360, // 6 hours default
  });
} 