import 'package:flutter/material.dart';
import '../models/child_device.dart';

class HomeProvider extends ChangeNotifier {
  List<ChildDevice> _devices = [];
  List<ActivityLog> _recentActivity = [];

  HomeProvider() {
    // Initialize with dummy data
    _devices = [
      ChildDevice(
        id: '1',
        childName: "Alex",
        deviceName: "Samsung Galaxy S21",
        isOnline: true,
        dailyScreenTime: 252, // 4h 12m
      ),
    ];

    _recentActivity = [
      ActivityLog(
        type: ActivityType.appUsage,
        title: 'YouTube Kids opened',
        timestamp: DateTime.now().subtract(const Duration(minutes: 2)),
      ),
      ActivityLog(
        type: ActivityType.screenTime,
        title: 'Screen time limit reached',
        timestamp: DateTime.now().subtract(const Duration(minutes: 15)),
      ),
      ActivityLog(
        type: ActivityType.location,
        title: 'Arrived at School',
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      ),
    ];
  }

  List<ChildDevice> get devices => _devices;
  List<ActivityLog> get recentActivity => _recentActivity;

  void toggleDeviceStatus(String deviceId) {
    final deviceIndex = _devices.indexWhere((device) => device.id == deviceId);
    if (deviceIndex != -1) {
      _devices[deviceIndex].isOnline = !_devices[deviceIndex].isOnline;
      notifyListeners();
    }
  }

  void addActivity(ActivityLog activity) {
    _recentActivity.insert(0, activity);
    if (_recentActivity.length > 10) {
      _recentActivity.removeLast();
    }
    notifyListeners();
  }

  void addDevice(ChildDevice device) {
    _devices.add(device);
    notifyListeners();
  }
}

class ActivityLog {
  final ActivityType type;
  final String title;
  final DateTime timestamp;

  ActivityLog({
    required this.type,
    required this.title,
    required this.timestamp,
  });

  String get timeAgo {
    final difference = DateTime.now().difference(timestamp);
    if (difference.inMinutes < 60) {
      return '${difference.inMinutes} minutes ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else {
      return '${difference.inDays} days ago';
    }
  }

  IconData get icon {
    switch (type) {
      case ActivityType.appUsage:
        return Icons.apps;
      case ActivityType.screenTime:
        return Icons.timer;
      case ActivityType.location:
        return Icons.location_on;
      case ActivityType.security:
        return Icons.security;
    }
  }
}

enum ActivityType {
  appUsage,
  screenTime,
  location,
  security,
} 