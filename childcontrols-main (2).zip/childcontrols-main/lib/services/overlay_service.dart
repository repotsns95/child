import 'package:flutter/material.dart';

class OverlayService {
  static OverlayEntry? _overlayEntry;

  static void showBlockingOverlay(BuildContext context, String appName) {
    if (_overlayEntry != null) return;

    _overlayEntry = OverlayEntry(
      builder: (context) => BlockingOverlay(appName: appName),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }

  static void hideBlockingOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }
}

class BlockingOverlay extends StatelessWidget {
  final String appName;

  const BlockingOverlay({
    super.key,
    required this.appName,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black87,
      child: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.block,
                color: Colors.white,
                size: 64,
              ),
              const SizedBox(height: 16),
              Text(
                '$appName is blocked',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Please contact your parent to access this app',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  OverlayService.hideBlockingOverlay();
                },
                child: const Text('Return to Home'),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 