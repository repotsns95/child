import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../firebase_options.dart';

class FirebaseService {
  static Future<void> initialize() async {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  }

  static Future<void> setupFirestoreRules() async {
    // This is just a reference - actual rules should be set in Firebase Console
    const rules = '''
      rules_version = '2';
      service cloud.firestore {
        match /databases/{database}/documents {
          match /parents/{parentId} {
            allow read, write: if request.auth != null && request.auth.uid == parentId;
            
            match /children/{childId} {
              allow read, write: if request.auth != null && request.auth.uid == parentId;
              
              match /usage/{usageId} {
                allow read: if request.auth != null && request.auth.uid == parentId;
                allow write: if request.auth != null;
              }
            }
          }
        }
      }
    ''';
  }
} 