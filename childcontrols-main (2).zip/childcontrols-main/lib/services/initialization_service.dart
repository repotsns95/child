import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config/debug_config.dart';
import 'firebase_service.dart';
import 'background_service.dart';
import 'permissions_service.dart';

class InitializationService {
  static Future<bool> initialize(BuildContext context) async {
    try {
      // Initialize Firebase
      await FirebaseService.initialize();
      DebugConfig.log('Firebase initialized');

      // Request permissions
      final permissionsGranted = await PermissionsService.requestRequiredPermissions(context);
      if (!permissionsGranted) {
        await PermissionsService.showPermissionDialog(context);
        return false;
      }
      DebugConfig.log('Permissions granted');

      // Initialize background service
      await BackgroundMonitoringService.initializeService();
      DebugConfig.log('Background service initialized');

      // Initialize preferences
      await _initializePreferences();
      DebugConfig.log('Preferences initialized');

      return true;
    } catch (e) {
      DebugConfig.logError('Initialization error', e as Exception);
      return false;
    }
  }

  static Future<void> _initializePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Set default values if not already set
    if (!prefs.containsKey('first_run')) {
      await prefs.setBool('first_run', true);
      await prefs.setInt('today_usage', 0);
      await prefs.setStringList('allowed_apps', []);
    }
  }
} 