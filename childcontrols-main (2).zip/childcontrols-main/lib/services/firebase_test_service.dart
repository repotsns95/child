import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../config/debug_config.dart';

class FirebaseTestService {
  static Future<bool> testFirebaseConnection() async {
    try {
      // Test Firebase Core
      final app = Firebase.app();
      DebugConfig.log('Firebase Core Test: ${app.name} initialized');

      // Test Firestore
      final firestore = FirebaseFirestore.instance;
      final testDoc = await firestore.collection('test').doc('connection').set({
        'timestamp': FieldValue.serverTimestamp(),
        'test': 'Firebase connection test',
      });
      DebugConfig.log('Firestore Test: Write successful');

      // Test Auth
      final auth = FirebaseAuth.instance;
      final testSignIn = await auth.signInAnonymously();
      DebugConfig.log('Auth Test: Anonymous sign-in successful');

      return true;
    } catch (e) {
      DebugConfig.logError('Firebase test failed', e as Exception);
      return false;
    }
  }

  static Future<Map<String, bool>> detailedFirebaseTest() async {
    final results = <String, bool>{};

    try {
      // Test Firebase Core
      final app = Firebase.app();
      results['core'] = app.name.isNotEmpty;
    } catch (e) {
      results['core'] = false;
      DebugConfig.logError('Firebase Core test failed', e as Exception);
    }

    try {
      // Test Firestore
      final firestore = FirebaseFirestore.instance;
      await firestore.collection('test').doc('connection').set({
        'timestamp': FieldValue.serverTimestamp(),
      });
      results['firestore'] = true;
    } catch (e) {
      results['firestore'] = false;
      DebugConfig.logError('Firestore test failed', e as Exception);
    }

    try {
      // Test Auth
      final auth = FirebaseAuth.instance;
      await auth.signInAnonymously();
      results['auth'] = true;
    } catch (e) {
      results['auth'] = false;
      DebugConfig.logError('Auth test failed', e as Exception);
    }

    return results;
  }
} 