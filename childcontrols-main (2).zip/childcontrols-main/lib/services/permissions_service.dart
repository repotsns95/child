import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';

class PermissionsService {
  static Future<bool> requestRequiredPermissions(BuildContext context) async {
    final deviceInfo = DeviceInfoPlugin();
    
    if (Theme.of(context).platform == TargetPlatform.android) {
      final androidInfo = await deviceInfo.androidInfo;
      
      // Request different permissions based on Android version
      if (androidInfo.version.sdkInt >= 30) { // Android 11 or higher
        final permissions = await Future.wait([
          Permission.accessNotificationPolicy.request(),
          Permission.systemAlertWindow.request(),
          Permission.packageUsageStats.request(),
        ]);

        return permissions.every((status) => status.isGranted);
      } else {
        final permissions = await Future.wait([
          Permission.accessNotificationPolicy.request(),
          Permission.systemAlertWindow.request(),
        ]);

        return permissions.every((status) => status.isGranted);
      }
    } else if (Theme.of(context).platform == TargetPlatform.iOS) {
      final permissions = await Future.wait([
        Permission.notification.request(),
        Permission.appTrackingTransparency.request(),
      ]);

      return permissions.every((status) => status.isGranted);
    }

    return false;
  }

  static Future<void> showPermissionDialog(BuildContext context) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Permissions Required'),
        content: const Text(
          'This app requires certain permissions to monitor and control device usage. '
          'Please grant all requested permissions to continue.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              openAppSettings();
            },
            child: const Text('Open Settings'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }
} 