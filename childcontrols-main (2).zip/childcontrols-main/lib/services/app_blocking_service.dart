import 'package:device_apps/device_apps.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';

class AppBlockingService {
  static const String _blockedAppsKey = 'blocked_apps';
  final LocalAuthentication _localAuth = LocalAuthentication();

  Future<void> blockApp(String packageName) async {
    final prefs = await SharedPreferences.getInstance();
    final blockedApps = prefs.getStringList(_blockedAppsKey) ?? [];
    
    if (!blockedApps.contains(packageName)) {
      blockedApps.add(packageName);
      await prefs.setStringList(_blockedAppsKey, blockedApps);
    }
  }

  Future<void> unblockApp(String packageName) async {
    final prefs = await SharedPreferences.getInstance();
    final blockedApps = prefs.getStringList(_blockedAppsKey) ?? [];
    
    if (blockedApps.contains(packageName)) {
      blockedApps.remove(packageName);
      await prefs.setStringList(_blockedAppsKey, blockedApps);
    }
  }

  Future<bool> isAppBlocked(String packageName) async {
    final prefs = await SharedPreferences.getInstance();
    final blockedApps = prefs.getStringList(_blockedAppsKey) ?? [];
    return blockedApps.contains(packageName);
  }

  Future<bool> authenticateParent() async {
    try {
      final canAuthenticate = await _localAuth.canCheckBiometrics;
      if (!canAuthenticate) return false;

      return await _localAuth.authenticate(
        localizedReason: 'Please authenticate to modify app restrictions',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false,
        ),
      );
    } on PlatformException {
      return false;
    }
  }

  Future<void> enforceRestrictions() async {
    final service = FlutterBackgroundService();
    final prefs = await SharedPreferences.getInstance();
    final blockedApps = prefs.getStringList(_blockedAppsKey) ?? [];

    // Get running apps
    final runningApps = await DeviceApps.getInstalledApplications(
      onlyAppsWithLaunchIntent: true,
      includeSystemApps: false,
    );

    for (var app in runningApps) {
      if (blockedApps.contains(app.packageName)) {
        service.invoke('blockApp', {
          'packageName': app.packageName,
          'action': 'block',
        });
      }
    }
  }
} 