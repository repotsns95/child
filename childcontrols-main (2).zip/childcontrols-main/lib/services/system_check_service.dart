import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../config/debug_config.dart';

class SystemCheckService {
  static Future<bool> verifySystem() async {
    try {
      // Check device info
      final deviceInfo = DeviceInfoPlugin();
      if (Theme.of(context).platform == TargetPlatform.android) {
        final androidInfo = await deviceInfo.androidInfo;
        DebugConfig.log('Android version: ${androidInfo.version.release}');
      } else if (Theme.of(context).platform == TargetPlatform.iOS) {
        final iosInfo = await deviceInfo.iosInfo;
        DebugConfig.log('iOS version: ${iosInfo.systemVersion}');
      }

      // Check app version
      final packageInfo = await PackageInfo.fromPlatform();
      DebugConfig.log('App version: ${packageInfo.version}');

      // Check Firebase connection
      final firebaseApp = Firebase.app();
      DebugConfig.log('Firebase initialized: ${firebaseApp.name}');

      return true;
    } catch (e) {
      DebugConfig.logError('System check failed', e as Exception);
      return false;
    }
  }
} 