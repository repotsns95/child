import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DevicePairingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<String?> getDeviceId() async {
    final deviceInfo = DeviceInfoPlugin();
    if (await deviceInfo.androidInfo != null) {
      final androidInfo = await deviceInfo.androidInfo;
      return androidInfo.id;
    } else if (await deviceInfo.iosInfo != null) {
      final iosInfo = await deviceInfo.iosInfo;
      return iosInfo.identifierForVendor;
    }
    return null;
  }

  Future<void> pairDevice(String parentId, String childId) async {
    final deviceId = await getDeviceId();
    if (deviceId == null) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('device_id', deviceId);
    await prefs.setString('parent_id', parentId);
    await prefs.setString('child_id', childId);

    await _firestore
        .collection('parents')
        .doc(parentId)
        .collection('children')
        .doc(childId)
        .update({
      'deviceId': deviceId,
      'lastPaired': FieldValue.serverTimestamp(),
    });
  }

  Future<bool> isDevicePaired() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('device_id') && 
           prefs.containsKey('parent_id') && 
           prefs.containsKey('child_id');
  }
} 