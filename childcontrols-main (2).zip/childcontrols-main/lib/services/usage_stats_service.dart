import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/child_profile.dart';

class UsageStatsService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> recordUsage(String parentId, String childId, String appPackage, int minutes) async {
    try {
      final date = DateTime.now().toIso8601String().split('T')[0];
      
      await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .doc(childId)
          .collection('usage')
          .doc(date)
          .set({
        'date': date,
        'totalMinutes': FieldValue.increment(minutes),
        'apps': {
          appPackage: FieldValue.increment(minutes),
        },
      }, SetOptions(merge: true));
    } catch (e) {
      print('Error recording usage: $e');
    }
  }

  Future<Map<String, dynamic>> getDailyUsage(String parentId, String childId, String date) async {
    try {
      final doc = await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .doc(childId)
          .collection('usage')
          .doc(date)
          .get();

      return doc.data() ?? {'totalMinutes': 0, 'apps': {}};
    } catch (e) {
      print('Error getting daily usage: $e');
      return {'totalMinutes': 0, 'apps': {}};
    }
  }

  Future<Map<String, dynamic>> getWeeklyUsage(String parentId, String childId) async {
    try {
      final endDate = DateTime.now();
      final startDate = endDate.subtract(const Duration(days: 7));
      
      final querySnapshot = await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .doc(childId)
          .collection('usage')
          .where('date', isGreaterThanOrEqualTo: startDate.toIso8601String().split('T')[0])
          .where('date', isLessThanOrEqualTo: endDate.toIso8601String().split('T')[0])
          .get();

      final Map<String, dynamic> weeklyStats = {
        'totalMinutes': 0,
        'dailyUsage': {},
        'appUsage': {},
      };

      for (var doc in querySnapshot.docs) {
        final data = doc.data();
        final date = data['date'] as String;
        final totalMinutes = data['totalMinutes'] as int;
        final apps = data['apps'] as Map<String, dynamic>;

        weeklyStats['totalMinutes'] += totalMinutes;
        weeklyStats['dailyUsage'][date] = totalMinutes;

        apps.forEach((app, minutes) {
          if (weeklyStats['appUsage'][app] == null) {
            weeklyStats['appUsage'][app] = 0;
          }
          weeklyStats['appUsage'][app] += minutes;
        });
      }

      return weeklyStats;
    } catch (e) {
      print('Error getting weekly usage: $e');
      return {
        'totalMinutes': 0,
        'dailyUsage': {},
        'appUsage': {},
      };
    }
  }

  Future<void> resetDailyUsage() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('today_usage', 0);
  }
} 