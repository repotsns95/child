import 'dart:async';
import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:device_apps/device_apps.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/child_profile.dart';

class BackgroundMonitoringService {
  static Future<void> initializeService() async {
    final service = FlutterBackgroundService();

    await service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onStart,
        autoStart: true,
        isForegroundMode: true,
        notificationChannelId: 'child_controls_channel',
        initialNotificationTitle: 'Child Controls Active',
        initialNotificationContent: 'Monitoring device usage',
        foregroundServiceNotificationId: 888,
      ),
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: onStart,
        onBackground: onIosBackground,
      ),
    );
  }

  static Future<bool> onIosBackground(ServiceInstance service) async {
    return true;
  }

  @pragma('vm:entry-point')
  static void onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();

    if (service is AndroidServiceInstance) {
      service.on('setAsForeground').listen((event) {
        service.setAsForegroundService();
      });

      service.on('setAsBackground').listen((event) {
        service.setAsBackgroundService();
      });
    }

    service.on('stopService').listen((event) {
      service.stopSelf();
    });

    Timer.periodic(const Duration(minutes: 1), (timer) async {
      await _checkUsageAndRestrictions(service);
    });
  }

  static Future<void> _checkUsageAndRestrictions(ServiceInstance service) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? deviceId = prefs.getString('device_id');
      final int? screenTimeLimit = prefs.getInt('screen_time_limit');
      final List<String> allowedApps = prefs.getStringList('allowed_apps') ?? [];

      if (deviceId == null || screenTimeLimit == null) return;

      // Check current app usage
      final runningApps = await DeviceApps.getInstalledApplications(
        onlyAppsWithLaunchIntent: true,
        includeAppIcons: false,
      );

      for (var app in runningApps) {
        if (!allowedApps.contains(app.packageName)) {
          // Block unauthorized apps
          // Note: This requires root access on Android
          // For non-rooted devices, you'll need to implement alternative restrictions
        }
      }

      // Update usage statistics
      final currentUsage = prefs.getInt('today_usage') ?? 0;
      await prefs.setInt('today_usage', currentUsage + 1);

      if (currentUsage >= screenTimeLimit) {
        service.invoke('timeLimit', {
          'exceeded': true,
          'message': 'Screen time limit exceeded',
        });
      }
    } catch (e) {
      print('Error in background service: $e');
    }
  }
} 