class ChildProfile {
  final String id;
  final String name;
  final int age;
  final String deviceId;
  final List<String> allowedApps;
  final int screenTimeLimit;
  final Map<String, int> appTimeLimit;
  final bool isActive;

  ChildProfile({
    required this.id,
    required this.name,
    required this.age,
    required this.deviceId,
    required this.allowedApps,
    required this.screenTimeLimit,
    required this.appTimeLimit,
    this.isActive = true,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'age': age,
      'deviceId': deviceId,
      'allowedApps': allowedApps,
      'screenTimeLimit': screenTimeLimit,
      'appTimeLimit': appTimeLimit,
      'isActive': isActive,
    };
  }

  factory ChildProfile.fromJson(Map<String, dynamic> json) {
    return ChildProfile(
      id: json['id'],
      name: json['name'],
      age: json['age'],
      deviceId: json['deviceId'],
      allowedApps: List<String>.from(json['allowedApps']),
      screenTimeLimit: json['screenTimeLimit'],
      appTimeLimit: Map<String, int>.from(json['appTimeLimit']),
      isActive: json['isActive'] ?? true,
    );
  }
} 