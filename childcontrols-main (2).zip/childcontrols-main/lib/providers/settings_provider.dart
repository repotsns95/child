import 'package:flutter/foundation.dart';
import 'package:shared_preferences.dart';

class SettingsProvider with ChangeNotifier {
  bool _notificationsEnabled = true;
  bool _biometricAuthEnabled = true;
  String _deviceMode = 'parent'; // 'parent' or 'child'

  bool get notificationsEnabled => _notificationsEnabled;
  bool get biometricAuthEnabled => _biometricAuthEnabled;
  String get deviceMode => _deviceMode;

  SettingsProvider() {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
    _biometricAuthEnabled = prefs.getBool('biometric_auth_enabled') ?? true;
    _deviceMode = prefs.getString('device_mode') ?? 'parent';
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    _notificationsEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', value);
    notifyListeners();
  }

  Future<void> setBiometricAuthEnabled(bool value) async {
    _biometricAuthEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('biometric_auth_enabled', value);
    notifyListeners();
  }

  Future<void> setDeviceMode(String mode) async {
    _deviceMode = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('device_mode', mode);
    notifyListeners();
  }
} 