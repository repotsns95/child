import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/child_profile.dart';

class ChildProfileProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<ChildProfile> _profiles = [];

  List<ChildProfile> get profiles => _profiles;

  Future<void> loadProfiles(String parentId) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .get();

      _profiles = snapshot.docs
          .map((doc) => ChildProfile.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
      
      notifyListeners();
    } catch (e) {
      print('Error loading profiles: $e');
    }
  }

  Future<void> addProfile(ChildProfile profile, String parentId) async {
    try {
      await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .doc(profile.id)
          .set(profile.toJson());

      _profiles.add(profile);
      notifyListeners();
    } catch (e) {
      print('Error adding profile: $e');
    }
  }

  Future<void> updateProfile(ChildProfile profile, String parentId) async {
    try {
      await _firestore
          .collection('parents')
          .doc(parentId)
          .collection('children')
          .doc(profile.id)
          .update(profile.toJson());

      int index = _profiles.indexWhere((p) => p.id == profile.id);
      if (index != -1) {
        _profiles[index] = profile;
        notifyListeners();
      }
    } catch (e) {
      print('Error updating profile: $e');
    }
  }
} 