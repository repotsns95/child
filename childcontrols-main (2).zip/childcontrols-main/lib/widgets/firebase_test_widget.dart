import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseTestWidget extends StatelessWidget {
  const FirebaseTestWidget({super.key});

  Future<void> _testFirestore() async {
    try {
      final firestore = FirebaseFirestore.instance;
      await firestore.collection('test').doc('connection').set({
        'timestamp': FieldValue.serverTimestamp(),
        'test': 'Manual connection test',
      });
      print('Firestore write successful');
      
      final doc = await firestore.collection('test').doc('connection').get();
      print('Firestore read successful: ${doc.data()}');
    } catch (e) {
      print('Firestore test failed: $e');
    }
  }

  Future<void> _testAuth() async {
    try {
      final auth = FirebaseAuth.instance;
      final result = await auth.signInAnonymously();
      print('Auth successful - UID: ${result.user?.uid}');
    } catch (e) {
      print('Auth test failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Firebase Test Panel',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _testFirestore,
                  child: const Text('Test Firestore'),
                ),
                ElevatedButton(
                  onPressed: _testAuth,
                  child: const Text('Test Auth'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
} 