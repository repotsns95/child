class AppConstants {
  static const String appName = 'Child Controls';
  static const String appVersion = '1.0.0';
  static const String appCopyright = '© 2025 Child Controls';
  
  static const int defaultScreenTimeLimit = 120; // 2 hours in minutes
  static const int warningThreshold = 15; // Show warning when 15 minutes remaining
  
  static const Duration backgroundServiceInterval = Duration(minutes: 1);
  static const Duration syncInterval = Duration(minutes: 15);
} 