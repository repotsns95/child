import 'package:flutter/material.dart';
import '../screens/login_screen.dart';
import '../screens/register_screen.dart';
import '../screens/dashboard_screen.dart';
import '../screens/child_setup_screen.dart';
import '../screens/child_home_screen.dart';
import '../screens/parent_settings_screen.dart';
import '../screens/add_child_screen.dart';
import '../screens/app_restrictions_screen.dart';
import '../screens/screen_time_settings_screen.dart';
import '../screens/usage_stats_screen.dart';
import '../screens/device_mode_screen.dart';
import '../screens/firebase_test_screen.dart';

class AppRoutes {
  static Map<String, WidgetBuilder> get routes => {
    '/device_mode': (context) => const DeviceModeScreen(),
    '/': (context) => const LoginScreen(),
    '/firebase_test': (context) => const FirebaseTestScreen(),
    '/register': (context) => const RegisterScreen(),
    '/dashboard': (context) => const DashboardScreen(),
    '/child_setup': (context) => const ChildSetupScreen(),
    '/child_home': (context) => const ChildHomeScreen(),
    '/settings': (context) => const ParentSettingsScreen(),
    '/add_child': (context) => const AddChildScreen(),
    '/app_restrictions': (context) => const AppRestrictionsScreen(),
    '/screen_time': (context) => const ScreenTimeSettingsScreen(),
    '/usage_stats': (context) => const UsageStatsScreen(),
  };
} 