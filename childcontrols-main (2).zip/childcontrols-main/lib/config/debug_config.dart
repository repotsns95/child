class DebugConfig {
  static bool get isDebugMode => true; // Set to false for production
  
  static void logError(String message, [Exception? error]) {
    if (isDebugMode) {
      print('Error: $message');
      if (error != null) {
        print('Exception details: $error');
      }
    }
  }
  
  static void log(String message) {
    if (isDebugMode) {
      print('Log: $message');
    }
  }
} 