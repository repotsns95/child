import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseTestUtils {
  static Future<Map<String, String>> runDiagnostics() async {
    final results = <String, String>{};
    
    // Test Firebase initialization
    try {
      final app = Firebase.app();
      results['initialization'] = 'OK: ${app.name}';
    } catch (e) {
      results['initialization'] = 'Failed: $e';
    }

    // Test Firestore
    try {
      final firestore = FirebaseFirestore.instance;
      
      // Write test
      await firestore.collection('diagnostics').doc('test').set({
        'timestamp': FieldValue.serverTimestamp(),
      });
      
      // Read test
      final doc = await firestore.collection('diagnostics').doc('test').get();
      results['firestore'] = 'OK: Read/Write successful';
    } catch (e) {
      results['firestore'] = 'Failed: $e';
    }

    // Test Authentication
    try {
      final auth = FirebaseAuth.instance;
      if (auth.currentUser == null) {
        final result = await auth.signInAnonymously();
        results['auth'] = 'OK: Anonymous auth successful';
      } else {
        results['auth'] = 'OK: Already authenticated';
      }
    } catch (e) {
      results['auth'] = 'Failed: $e';
    }

    return results;
  }

  static Future<void> printDiagnostics() async {
    print('=== Firebase Diagnostics ===');
    final results = await runDiagnostics();
    results.forEach((key, value) {
      print('$key: $value');
    });
    print('=========================');
  }
} 