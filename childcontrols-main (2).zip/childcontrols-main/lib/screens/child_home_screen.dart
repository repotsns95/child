import 'package:flutter/material.dart';
import '../services/app_blocking_service.dart';
import '../services/usage_stats_service.dart';

class ChildHomeScreen extends StatefulWidget {
  const ChildHomeScreen({super.key});

  @override
  State<ChildHomeScreen> createState() => _ChildHomeScreenState();
}

class _ChildHomeScreenState extends State<ChildHomeScreen> {
  final _usageStatsService = UsageStatsService();
  final _appBlockingService = AppBlockingService();
  int _remainingTime = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRemainingTime();
  }

  Future<void> _loadRemainingTime() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final screenTimeLimit = prefs.getInt('screen_time_limit') ?? 120;
      final usedTime = prefs.getInt('today_usage') ?? 0;
      setState(() => _remainingTime = screenTimeLimit - usedTime);
    } catch (e) {
      print('Error loading remaining time: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Child Controls'),
        automaticallyImplyLeading: false,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          const Text(
                            'Remaining Screen Time',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${_remainingTime ~/ 60}h ${_remainingTime % 60}m',
                            style: const TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Allowed Apps',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: FutureBuilder<List<Application>>(
                      future: DeviceApps.getInstalledApplications(
                        onlyAppsWithLaunchIntent: true,
                        includeSystemApps: false,
                      ),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        final apps = snapshot.data!;
                        return ListView.builder(
                          itemCount: apps.length,
                          itemBuilder: (context, index) {
                            final app = apps[index];
                            return FutureBuilder<bool>(
                              future: _appBlockingService.isAppBlocked(app.packageName),
                              builder: (context, snapshot) {
                                final isBlocked = snapshot.data ?? true;
                                return ListTile(
                                  leading: app is ApplicationWithIcon
                                      ? Image.memory(app.icon, width: 40)
                                      : const Icon(Icons.android),
                                  title: Text(app.appName),
                                  trailing: Icon(
                                    isBlocked ? Icons.block : Icons.check_circle,
                                    color: isBlocked ? Colors.red : Colors.green,
                                  ),
                                );
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
    );
  }
} 