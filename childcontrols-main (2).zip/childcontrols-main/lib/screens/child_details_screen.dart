import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/child_profile.dart';
import '../providers/child_profile_provider.dart';
import 'app_restrictions_screen.dart';
import 'screen_time_settings_screen.dart';

class ChildDetailsScreen extends StatelessWidget {
  final ChildProfile profile;

  const ChildDetailsScreen({
    super.key,
    required this.profile,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(profile.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _showEditDialog(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildInfoCard(context),
          const SizedBox(height: 16),
          _buildActionButtons(context),
          const SizedBox(height: 16),
          _buildScreenTimeCard(context),
          const SizedBox(height: 16),
          _buildAppRestrictionsCard(context),
        ],
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Profile Information',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const Divider(),
            ListTile(
              title: const Text('Name'),
              subtitle: Text(profile.name),
            ),
            ListTile(
              title: const Text('Age'),
              subtitle: Text('${profile.age} years old'),
            ),
            ListTile(
              title: const Text('Device ID'),
              subtitle: Text(profile.deviceId),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ScreenTimeSettingsScreen(profile: profile),
              ),
            );
          },
          icon: const Icon(Icons.timer),
          label: const Text('Screen Time'),
        ),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AppRestrictionsScreen(profile: profile),
              ),
            );
          },
          icon: const Icon(Icons.block),
          label: const Text('App Restrictions'),
        ),
      ],
    );
  }

  Widget _buildScreenTimeCard(BuildContext context) {
    final hours = profile.screenTimeLimit ~/ 60;
    final minutes = profile.screenTimeLimit % 60;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Screen Time Limit',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.timer),
              title: Text('$hours hours $minutes minutes per day'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppRestrictionsCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'App Restrictions',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const Divider(),
            if (profile.allowedApps.isEmpty)
              const ListTile(
                title: Text('No app restrictions set'),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: profile.allowedApps.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: const Icon(Icons.apps),
                    title: Text(profile.allowedApps[index]),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _showEditDialog(BuildContext context) async {
    final nameController = TextEditingController(text: profile.name);
    final ageController = TextEditingController(text: profile.age.toString());

    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Profile'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: ageController,
              decoration: const InputDecoration(labelText: 'Age'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              final updatedProfile = ChildProfile(
                id: profile.id,
                name: nameController.text,
                age: int.parse(ageController.text),
                deviceId: profile.deviceId,
                allowedApps: profile.allowedApps,
                screenTimeLimit: profile.screenTimeLimit,
                appTimeLimit: profile.appTimeLimit,
              );

              final user = FirebaseAuth.instance.currentUser;
              if (user != null) {
                await Provider.of<ChildProfileProvider>(context, listen: false)
                    .updateProfile(updatedProfile, user.uid);
              }

              if (context.mounted) {
                Navigator.pop(context);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
} 