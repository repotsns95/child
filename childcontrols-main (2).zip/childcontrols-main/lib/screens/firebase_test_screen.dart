import 'package:flutter/material.dart';
import '../services/firebase_test_service.dart';

class FirebaseTestScreen extends StatefulWidget {
  const FirebaseTestScreen({super.key});

  @override
  State<FirebaseTestScreen> createState() => _FirebaseTestScreenState();
}

class _FirebaseTestScreenState extends State<FirebaseTestScreen> {
  Map<String, bool> _testResults = {};
  bool _isLoading = false;

  Future<void> _runTests() async {
    setState(() => _isLoading = true);
    try {
      final results = await FirebaseTestService.detailedFirebaseTest();
      setState(() => _testResults = results);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Firebase Test'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: _isLoading ? null : _runTests,
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : const Text('Run Firebase Tests'),
            ),
            const SizedBox(height: 24),
            if (_testResults.isNotEmpty) ...[
              const Text(
                'Test Results:',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildTestResult('Firebase Core', _testResults['core']),
              _buildTestResult('Firestore', _testResults['firestore']),
              _buildTestResult('Authentication', _testResults['auth']),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTestResult(String testName, bool? passed) {
    return ListTile(
      leading: Icon(
        passed == true ? Icons.check_circle : Icons.error,
        color: passed == true ? Colors.green : Colors.red,
      ),
      title: Text(testName),
      subtitle: Text(passed == true ? 'Passed' : 'Failed'),
    );
  }
} 