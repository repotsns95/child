import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/child_profile.dart';
import '../services/usage_stats_service.dart';
import 'package:fl_chart/fl_chart.dart';

class UsageStatsScreen extends StatefulWidget {
  final ChildProfile profile;

  const UsageStatsScreen({
    super.key,
    required this.profile,
  });

  @override
  State<UsageStatsScreen> createState() => _UsageStatsScreenState();
}

class _UsageStatsScreenState extends State<UsageStatsScreen> {
  final _usageStatsService = UsageStatsService();
  bool _isLoading = true;
  Map<String, dynamic> _weeklyStats = {};

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    setState(() => _isLoading = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final stats = await _usageStatsService.getWeeklyUsage(
          user.uid,
          widget.profile.id,
        );
        setState(() => _weeklyStats = stats);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Usage Statistics'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildWeeklyChart(),
                  const SizedBox(height: 24),
                  _buildAppUsageList(),
                ],
              ),
            ),
    );
  }

  Widget _buildWeeklyChart() {
    final dailyUsage = _weeklyStats['dailyUsage'] as Map<String, dynamic>;
    final spots = dailyUsage.entries.map((e) {
      final date = DateTime.parse(e.key);
      return FlSpot(
        date.weekday.toDouble(),
        (e.value as int).toDouble() / 60, // Convert minutes to hours
      );
    }).toList();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Weekly Usage',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: true),
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          switch (value.toInt()) {
                            case 1:
                              return const Text('Mon');
                            case 2:
                              return const Text('Tue');
                            case 3:
                              return const Text('Wed');
                            case 4:
                              return const Text('Thu');
                            case 5:
                              return const Text('Fri');
                            case 6:
                              return const Text('Sat');
                            case 7:
                              return const Text('Sun');
                            default:
                              return const Text('');
                          }
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          return Text('${value.toInt()}h');
                        },
                      ),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: Colors.blue,
                      dotData: FlDotData(show: true),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppUsageList() {
    final appUsage = _weeklyStats['appUsage'] as Map<String, dynamic>;
    final sortedApps = appUsage.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'App Usage',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: sortedApps.length,
              itemBuilder: (context, index) {
                final app = sortedApps[index];
                final hours = (app.value as int) ~/ 60;
                final minutes = (app.value as int) % 60;
                
                return ListTile(
                  title: Text(app.key),
                  trailing: Text('${hours}h ${minutes}m'),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
} 