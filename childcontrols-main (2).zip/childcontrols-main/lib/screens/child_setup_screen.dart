import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/device_pairing_service.dart';
import '../services/permissions_service.dart';
import '../providers/child_profile_provider.dart';

class ChildSetupScreen extends StatefulWidget {
  const ChildSetupScreen({super.key});

  @override
  State<ChildSetupScreen> createState() => _ChildSetupScreenState();
}

class _ChildSetupScreenState extends State<ChildSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _pairingCodeController = TextEditingController();
  final _devicePairingService = DevicePairingService();
  bool _isLoading = false;

  Future<void> _setupDevice() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);
      try {
        // Request necessary permissions
        final permissionsGranted = await PermissionsService.requestRequiredPermissions(context);
        if (!permissionsGranted) {
          await PermissionsService.showPermissionDialog(context);
          return;
        }

        // Parse pairing code (format: parentId:childId)
        final parts = _pairingCodeController.text.split(':');
        if (parts.length != 2) {
          throw Exception('Invalid pairing code');
        }

        await _devicePairingService.pairDevice(parts[0], parts[1]);

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Device setup successful')),
          );
          Navigator.pushReplacementNamed(context, '/child_home');
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      } finally {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Child Device Setup'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Enter the pairing code provided by your parent',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _pairingCodeController,
                decoration: const InputDecoration(
                  labelText: 'Pairing Code',
                  border: OutlineInputBorder(),
                  helperText: 'Format: PARENTID:CHILDID',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the pairing code';
                  }
                  if (!value.contains(':')) {
                    return 'Invalid pairing code format';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isLoading ? null : _setupDevice,
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('Setup Device'),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 