import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/notification_service.dart';
import '../providers/child_profile_provider.dart';
import '../widgets/firebase_test_widget.dart';

class ParentSettingsScreen extends StatefulWidget {
  const ParentSettingsScreen({super.key});

  @override
  State<ParentSettingsScreen> createState() => _ParentSettingsScreenState();
}

class _ParentSettingsScreenState extends State<ParentSettingsScreen> {
  final _authService = AuthService();
  final _notificationService = NotificationService();
  bool _notificationsEnabled = true;
  bool _biometricAuthEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    // Load settings from SharedPreferences
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          const FirebaseTestWidget(),
          const Divider(),
          ListTile(
            title: const Text('Notifications'),
            subtitle: const Text('Enable or disable notifications'),
            trailing: Switch(
              value: _notificationsEnabled,
              onChanged: (value) {
                setState(() => _notificationsEnabled = value);
                // Save setting
              },
            ),
          ),
          ListTile(
            title: const Text('Biometric Authentication'),
            subtitle: const Text('Use fingerprint or face ID for authentication'),
            trailing: Switch(
              value: _biometricAuthEnabled,
              onChanged: (value) {
                setState(() => _biometricAuthEnabled = value);
                // Save setting
              },
            ),
          ),
          ListTile(
            title: const Text('Account'),
            subtitle: const Text('Manage your account settings'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // Navigate to account settings
            },
          ),
          ListTile(
            title: const Text('Privacy Policy'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // Show privacy policy
            },
          ),
          ListTile(
            title: const Text('Terms of Service'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // Show terms of service
            },
          ),
          ListTile(
            title: const Text('About'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: 'Child Controls',
                applicationVersion: '1.0.0',
                applicationLegalese: '© 2025 Child Controls',
              );
            },
          ),
          ListTile(
            title: const Text('Test Firebase Connection'),
            subtitle: const Text('Verify Firebase services are working'),
            trailing: const Icon(Icons.cloud),
            onTap: () {
              Navigator.pushNamed(context, '/firebase_test');
            },
          ),
          ListTile(
            title: const Text('Sign Out'),
            textColor: Colors.red,
            trailing: const Icon(Icons.logout, color: Colors.red),
            onTap: () async {
              await _authService.signOut();
              if (mounted) {
                Navigator.pushReplacementNamed(context, '/login');
              }
            },
          ),
        ],
      ),
    );
  }
} 