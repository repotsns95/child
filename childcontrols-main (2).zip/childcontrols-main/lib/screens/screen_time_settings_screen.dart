import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/child_profile.dart';
import '../providers/child_profile_provider.dart';

class ScreenTimeSettingsScreen extends StatefulWidget {
  final ChildProfile profile;

  const ScreenTimeSettingsScreen({
    super.key,
    required this.profile,
  });

  @override
  State<ScreenTimeSettingsScreen> createState() => _ScreenTimeSettingsScreenState();
}

class _ScreenTimeSettingsScreenState extends State<ScreenTimeSettingsScreen> {
  late int _hours;
  late int _minutes;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _hours = widget.profile.screenTimeLimit ~/ 60;
    _minutes = widget.profile.screenTimeLimit % 60;
  }

  Future<void> _saveSettings() async {
    setState(() => _isLoading = true);
    try {
      final totalMinutes = (_hours * 60) + _minutes;
      final updatedProfile = ChildProfile(
        id: widget.profile.id,
        name: widget.profile.name,
        age: widget.profile.age,
        deviceId: widget.profile.deviceId,
        allowedApps: widget.profile.allowedApps,
        screenTimeLimit: totalMinutes,
        appTimeLimit: widget.profile.appTimeLimit,
      );

      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await Provider.of<ChildProfileProvider>(context, listen: false)
            .updateProfile(updatedProfile, user.uid);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Screen time settings updated')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Screen Time Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Daily Time Limit',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: _hours,
                            decoration: const InputDecoration(
                              labelText: 'Hours',
                              border: OutlineInputBorder(),
                            ),
                            items: List.generate(13, (index) {
                              return DropdownMenuItem(
                                value: index,
                                child: Text('$index hours'),
                              );
                            }),
                            onChanged: (value) {
                              if (value != null) {
                                setState(() => _hours = value);
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: _minutes,
                            decoration: const InputDecoration(
                              labelText: 'Minutes',
                              border: OutlineInputBorder(),
                            ),
                            items: List.generate(12, (index) {
                              return DropdownMenuItem(
                                value: index * 5,
                                child: Text('${index * 5} minutes'),
                              );
                            }),
                            onChanged: (value) {
                              if (value != null) {
                                setState(() => _minutes = value);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isLoading ? null : _saveSettings,
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : const Text('Save Settings'),
            ),
          ],
        ),
      ),
    );
  }
} 