import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';

class DeviceModeScreen extends StatelessWidget {
  const DeviceModeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Select Device Mode',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 48),
              ElevatedButton(
                onPressed: () async {
                  await context.read<SettingsProvider>().setDeviceMode('parent');
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/login');
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Icon(Icons.admin_panel_settings, size: 48),
                      SizedBox(height: 8),
                      Text('Parent Device'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () async {
                  await context.read<SettingsProvider>().setDeviceMode('child');
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/child_setup');
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Icon(Icons.child_care, size: 48),
                      SizedBox(height: 8),
                      Text('Child Device'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 