import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:device_apps/device_apps.dart';
import '../models/child_profile.dart';
import '../providers/child_profile_provider.dart';

class AppRestrictionsScreen extends StatefulWidget {
  final ChildProfile profile;

  const AppRestrictionsScreen({
    super.key,
    required this.profile,
  });

  @override
  State<AppRestrictionsScreen> createState() => _AppRestrictionsScreenState();
}

class _AppRestrictionsScreenState extends State<AppRestrictionsScreen> {
  List<Application> _installedApps = [];
  bool _isLoading = true;
  Set<String> _selectedApps = {};

  @override
  void initState() {
    super.initState();
    _loadApps();
    _selectedApps = Set.from(widget.profile.allowedApps);
  }

  Future<void> _loadApps() async {
    try {
      final apps = await DeviceApps.getInstalledApplications(
        onlyAppsWithLaunchIntent: true,
        includeSystemApps: true,
        includeAppIcons: true,
      );
      setState(() {
        _installedApps = apps;
        _isLoading = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  Future<void> _saveRestrictions() async {
    setState(() => _isLoading = true);
    try {
      final updatedProfile = ChildProfile(
        id: widget.profile.id,
        name: widget.profile.name,
        age: widget.profile.age,
        deviceId: widget.profile.deviceId,
        allowedApps: _selectedApps.toList(),
        screenTimeLimit: widget.profile.screenTimeLimit,
        appTimeLimit: widget.profile.appTimeLimit,
      );

      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await Provider.of<ChildProfileProvider>(context, listen: false)
            .updateProfile(updatedProfile, user.uid);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('App restrictions updated')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Restrictions'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: _installedApps.length,
                    itemBuilder: (context, index) {
                      final app = _installedApps[index];
                      return CheckboxListTile(
                        title: Text(app.appName),
                        subtitle: Text(app.packageName),
                        secondary: app is ApplicationWithIcon
                            ? Image.memory(app.icon, width: 40, height: 40)
                            : const Icon(Icons.android),
                        value: _selectedApps.contains(app.packageName),
                        onChanged: (bool? value) {
                          setState(() {
                            if (value ?? false) {
                              _selectedApps.add(app.packageName);
                            } else {
                              _selectedApps.remove(app.packageName);
                            }
                          });
                        },
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: _saveRestrictions,
                    child: const Text('Save Restrictions'),
                  ),
                ),
              ],
            ),
    );
  }
} 