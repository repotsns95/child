import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/login_screen.dart';
import 'providers/child_profile_provider.dart';
import 'providers/settings_provider.dart';
import 'services/initialization_service.dart';
import 'config/routes.dart';
import 'config/debug_config.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'utils/firebase_test_utils.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    
    // Run Firebase diagnostics
    if (DebugConfig.isDebugMode) {
      await FirebaseTestUtils.printDiagnostics();
    }
    
    // Quick Firebase test
    final firestore = FirebaseFirestore.instance;
    await firestore.collection('test').doc('connection').set({
      'timestamp': FieldValue.serverTimestamp(),
      'test': 'Initial connection test',
    });
    
    print('Firebase connection successful!');
  } catch (e) {
    print('Firebase initialization failed: $e');
  }
  
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      await InitializationService.initialize(context);
      setState(() => _initialized = true);
    } catch (e) {
      print('Error initializing app: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ChildProfileProvider()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
      ],
      child: Consumer<SettingsProvider>(
        builder: (context, settings, _) {
          return MaterialApp(
            title: 'Child Controls',
            theme: ThemeData(
              primarySwatch: Colors.blue,
              useMaterial3: true,
            ),
            routes: AppRoutes.routes,
            home: !_initialized
                ? const Center(child: CircularProgressIndicator())
                : settings.deviceMode == 'child'
                    ? const ChildHomeScreen()
                    : const LoginScreen(),
          );
        },
      ),
    );
  }
} 