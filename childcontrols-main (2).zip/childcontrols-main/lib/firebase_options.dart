// Generate this file using FlutterFire CLI:
// flutterfire configure
// This will create the firebase_options.dart file with your Firebase configuration 